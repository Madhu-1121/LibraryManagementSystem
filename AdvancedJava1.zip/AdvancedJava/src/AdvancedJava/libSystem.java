package AdvancedJava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class libSystem {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/librarymanagaement";
		String username = "root";
		String password = "root";

		try(Connection con = DriverManager.getConnection(url,username,password);
				Scanner scan = new Scanner(System.in);) {
			Class.forName("com.mysql.cj.jdbc.Driver");

			while(true) {
				System.out.println("*----LIBRARY MENU----*\n");
				System.out.println("1. View Books: ");
				System.out.println("2. Add Books: ");
				System.out.println("3. Delete Books: ");
				System.out.println("4. Update Books: ");
				System.out.println("5. View Users: ");
				System.out.println("6. Add User: ");
				System.out.println("7. Delete user: ");
				System.out.println("8. Exit: \n");

				System.out.println("Enter the Choice: ");
				int choice = scan.nextInt();

				if(choice==1) {
					Statement stmt = con.createStatement();	
					String querry = "Select * from books";
					ResultSet res = stmt.executeQuery(querry);

					System.out.println("**----Books List----**");

					while(res.next()) {
						int id = res.getInt(1);
						String title = res.getString(2);
						String author = res.getString(3);
						int quantity = res.getInt(4);

						System.out.println(" ID: " +id + ", Title: " + title + ", Author: " +author + ", Quantity: " + quantity);
					}
				}

				else if(choice == 2) {
					String querry = "Insert into books (id,title,author,quantity) Values (?,?,?,?)";
					PreparedStatement pstmt = con.prepareStatement(querry);

					System.out.println("Enter Book ID: ");
					pstmt.setInt(1, scan.nextInt());
					scan.nextLine();
					System.out.println("Enter Book Title: ");
					pstmt.setString(2, scan.nextLine());
					System.out.println("Enter Book Author: ");
					pstmt.setString(3, scan.nextLine());		
					System.out.println("Enter Book Quantity: ");
					pstmt.setInt(4, scan.nextInt());

					int i = pstmt.executeUpdate();

					System.out.println("Books Added SuccessFully");
				}

				else if(choice == 3) {
					String querry = "Delete from books where id = ?";
					PreparedStatement pstmt = con.prepareStatement(querry);

					System.out.println("Enter Book Id to Delete: ");
					int id = scan.nextInt();
					pstmt.setInt(1, id);

					int i = pstmt.executeUpdate();

					System.out.println("Book Deleted Succesfully");
				}

				else if(choice == 4) {
					String querry = "update books set id = ? where title = ?";
					PreparedStatement pstmt = con.prepareStatement(querry);

					System.out.println("Enter Updating book Id: ");
					int id = scan.nextInt();
					scan.nextLine();
					System.out.println("Enter The Book title You are Updating: ");
					String title = scan.nextLine();
					pstmt.setInt(1, id);
					pstmt.setString(2, title);

					int i = pstmt.executeUpdate();

					System.out.println("Book Updated SuccessFully.");
				}
				
				if(choice == 5) {
					Statement stmt = con.createStatement();	
					String querry = "Select * from user";
					ResultSet res = stmt.executeQuery(querry);

					System.out.println("**----Users List----**");

					while(res.next()) {
						int id = res.getInt(1);
						String name = res.getString(2);
						String email = res.getString(3);

						System.out.println("ID: " +id + ", Name: " + name + ", Email: " + email);
					}		
				}
				
				else if(choice == 6) {
					String querry = "Insert into user (id,name,email) Values (?,?,?)";
					PreparedStatement pstmt = con.prepareStatement(querry);

					System.out.println("Enter User ID: ");
					pstmt.setInt(1, scan.nextInt());
					scan.nextLine();
					System.out.println("Enter User Name: ");
					pstmt.setString(2, scan.nextLine());
					System.out.println("Enter User Email id: ");
					pstmt.setString(3, scan.nextLine());		

					int i = pstmt.executeUpdate();

					System.out.println("User Added SuccessFully.");
				}
				
				else if(choice == 7) {
					String querry = "Delete from user where id = ?";
					PreparedStatement pstmt = con.prepareStatement(querry);

					System.out.println("Enter User Id to Delete: ");
					int id = scan.nextInt();
					pstmt.setInt(1, id);

					int i = pstmt.executeUpdate();

					System.out.println("User Deleted Succesfully");
				}
				
				else if(choice == 8) {
					System.out.println("Exiting Library System. Thank You!.");
					break;
				}
				
				else {
					System.out.println("Invalid Choice. Please Try Again.");
				}
			}
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}

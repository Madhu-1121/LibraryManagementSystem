package AdvancedJava;
import java.sql.*;
import java.util.Scanner;

public class library {

	    static final String DB_URL = "jdbc:mysql://localhost:3306/librarymanagaement";
	    static final String USER = "root";
	    static final String PASS = "root"; // Replace with your MySQL password

	    public static void main(String[] args) {
	        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
	             Scanner sc = new Scanner(System.in)) {

	            while (true) {
	                System.out.println("\n--- Library Menu ---");
	                System.out.println("1. Add Book");
	                System.out.println("2. View Books");
	                System.out.println("3. Search Book");
	                System.out.println("4. Delete Book");
	                System.out.println("5. Exit");
	                System.out.print("Enter your choice: ");
	                int choice = sc.nextInt();
	                sc.nextLine(); // Consume newline

	                if (choice == 1) {
	                    System.out.print("Enter book title: ");
	                    String title = sc.nextLine();
	                    System.out.print("Enter author: ");
	                    String author = sc.nextLine();
	                    System.out.print("Enter quantity: ");
	                    int quantity = sc.nextInt();

	                    String sql = "INSERT INTO books (title, author, quantity) VALUES (?, ?, ?)";
	                    PreparedStatement pstmt = conn.prepareStatement(sql);
	                    pstmt.setString(1, title);
	                    pstmt.setString(2, author);
	                    pstmt.setInt(3, quantity);
	                    int rows = pstmt.executeUpdate();
	                    System.out.println(rows > 0 ? "Book added successfully." : "Failed to add book.");
	                }

	                else if (choice == 2) {
	                    String sql = "SELECT * FROM books";
	                    Statement stmt = conn.createStatement();
	                    ResultSet rs = stmt.executeQuery(sql);
	                    System.out.println("\n--- Book List ---");
	                    while (rs.next()) {
	                        System.out.println("ID: " + rs.getInt("id") +
	                                ", Title: " + rs.getString("title") +
	                                ", Author: " + rs.getString("author") +
	                                ", Quantity: " + rs.getInt("quantity"));
	                    }
	                }

	                else if (choice == 3) {
	                    System.out.print("Enter book title to search: ");
	                    String title = sc.nextLine();
	                    String sql = "SELECT * FROM books WHERE title LIKE ?";
	                    PreparedStatement pstmt = conn.prepareStatement(sql);
	                    pstmt.setString(1, "%" + title + "%");
	                    ResultSet rs = pstmt.executeQuery();

	                    boolean found = false;
	                    while (rs.next()) {
	                        found = true;
	                        System.out.println("ID: " + rs.getInt("id") +
	                                ", Title: " + rs.getString("title") +
	                                ", Author: " + rs.getString("author") +
	                                ", Quantity: " + rs.getInt("quantity"));
	                    }
	                    if (!found) {
	                        System.out.println("Book not found.");
	                    }
	                }

	                else if (choice == 4) {
	                    System.out.print("Enter book ID to delete: ");
	                    int id = sc.nextInt();
	                    String sql = "DELETE FROM books WHERE id = ?";
	                    PreparedStatement pstmt = conn.prepareStatement(sql);
	                    pstmt.setInt(1, id);
	                    int rows = pstmt.executeUpdate();
	                    System.out.println(rows > 0 ? "Book deleted successfully." : "Book not found.");
	                }

	                else if (choice == 5) {
	                    System.out.println("Exiting the system...");
	                    break;
	                }

	                else {
	                    System.out.println("Invalid choice. Please try again.");
	                }
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}
